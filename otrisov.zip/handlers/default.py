from aiogram import types
from aiogram.dispatcher import FSMContext

from misc import dp, bot
from keyboards import inline, default


@dp.message_handler(content_types=types.ContentTypes.ANY, state="*")
async def all_other_messages(message: types.Message):
    if message.content_type == "text":
        await message.reply("<b>Воспользуйтесь клавиатурой</b>")


@dp.callback_query_handler(lambda call: call.data == "del_message", state="*")
async def callback_del_message(call: types.callback_query, state: FSMContext):
    await state.finish()
    await bot.delete_message(call.message.chat.id, call.message.message_id)
