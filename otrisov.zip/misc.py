import logging
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage


bot = Bot(token="1682236765:AAEWyj-pdPkBxLA-f2a0XtbMo07DgfQ6Gt4", parse_mode=types.ParseMode.HTML)
memory_storage = MemoryStorage()
dp = Dispatcher(bot, storage=memory_storage)
logging.basicConfig(level=logging.INFO)

def only_numerics(p):
    seq_type= type(p)
    return seq_type().join(filter(seq_type.isdigit, p))
